package com.example.utsaplikasipenghitunggajikaryawan;

import android.os.Bundle;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class PetunjukActivityEries extends AppCompatActivity {

    // Developer / Peserta Ujian: Eries Defa Mahesa

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_petunjuk_eries);

        Button btnKembali = findViewById(R.id.btnKembali);
        btnKembali.setOnClickListener(v -> finish());
    }
}
