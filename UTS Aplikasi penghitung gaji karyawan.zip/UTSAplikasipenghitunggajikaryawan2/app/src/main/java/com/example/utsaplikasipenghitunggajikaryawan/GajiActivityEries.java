package com.example.utsaplikasipenghitunggajikaryawan;

import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.text.NumberFormat;
import java.util.Locale;

public class GajiActivityEries extends AppCompatActivity {

    // Developer / Peserta Ujian: Eries Defa Mahesa

    private EditText etNomorInduk, etNama, etGajiPokok, etTunjanganJabatan, etJumlahHariKerja;
    private TextView tvTunjanganMakan, tvTunjanganTransportasi, tvGajiKotor, tvGajiBersih;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gaji_eries);

        etNomorInduk = findViewById(R.id.etNomorInduk);
        etNama = findViewById(R.id.etNama);
        etGajiPokok = findViewById(R.id.etGajiPokok);
        etTunjanganJabatan = findViewById(R.id.etTunjanganJabatan);
        etJumlahHariKerja = findViewById(R.id.etJumlahHariKerja);

        tvTunjanganMakan = findViewById(R.id.tvTunjanganMakan);
        tvTunjanganTransportasi = findViewById(R.id.tvTunjanganTransportasi);
        tvGajiKotor = findViewById(R.id.tvGajiKotor);
        tvGajiBersih = findViewById(R.id.tvGajiBersih);

        Button btnHitung = findViewById(R.id.btnHitung);
        Button btnKembali = findViewById(R.id.btnKembali);

        btnHitung.setOnClickListener(v -> hitungGaji());

        btnKembali.setOnClickListener(v -> finish());
    }

    private void hitungGaji() {
        String strNomorInduk = etNomorInduk.getText().toString().trim();
        String strNama = etNama.getText().toString().trim();
        String strGajiPokok = etGajiPokok.getText().toString().trim();
        String strTunjanganJabatan = etTunjanganJabatan.getText().toString().trim();
        String strHariKerja = etJumlahHariKerja.getText().toString().trim();

        if (TextUtils.isEmpty(strNomorInduk) || TextUtils.isEmpty(strNama) ||
                TextUtils.isEmpty(strGajiPokok) || TextUtils.isEmpty(strTunjanganJabatan) ||
                TextUtils.isEmpty(strHariKerja)) {
            Toast.makeText(this, "Semua field harus diisi!", Toast.LENGTH_SHORT).show();
            return;
        }

        try {
            double gajiPokok = Double.parseDouble(strGajiPokok);
            double tunjanganJabatan = Double.parseDouble(strTunjanganJabatan);
            int jumlahHariKerja = Integer.parseInt(strHariKerja);

            // Perhitungan sesuai ketentuan
            // a. Tunjangan makan = jumlah hari kerja * Rp 10.000
            double tunjanganMakan = jumlahHariKerja * 10000.0;

            // b. Tunjangan transportasi = jumlah hari kerja * Rp 5.000
            double tunjanganTransportasi = jumlahHariKerja * 5000.0;

            // c. Gaji Kotor = gaji pokok + tunjangan jabatan + tunjangan makan + tunjangan transportasi
            double gajiKotor = gajiPokok + tunjanganJabatan + tunjanganMakan + tunjanganTransportasi;

            // d. Pajak 10% dari gaji kotor kurang pajak -> Gaji Bersih = Gaji Kotor - (10% * Gaji Kotor)
            double pajak = 0.10 * gajiKotor;
            double gajiBersih = gajiKotor - pajak;

            Locale localeID = Locale.forLanguageTag("id-ID");
            NumberFormat formatRupiah = NumberFormat.getCurrencyInstance(localeID);

            tvTunjanganMakan.setText(formatRupiah.format(tunjanganMakan));
            tvTunjanganTransportasi.setText(formatRupiah.format(tunjanganTransportasi));
            tvGajiKotor.setText(formatRupiah.format(gajiKotor));
            tvGajiBersih.setText(formatRupiah.format(gajiBersih));

        } catch (NumberFormatException e) {
            Toast.makeText(this, "Format angka tidak valid!", Toast.LENGTH_SHORT).show();
        }
    }
}
