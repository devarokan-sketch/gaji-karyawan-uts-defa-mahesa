package com.example.utsaplikasipenghitunggajikaryawan;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivityEries extends AppCompatActivity {

    // Developer / Peserta Ujian: Eries Defa Mahesa

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_eries);

        Button btnGajiPegawai = findViewById(R.id.btnGajiPegawai);
        Button btnPetunjuk = findViewById(R.id.btnPetunjuk);
        Button btnTentang = findViewById(R.id.btnTentang);
        Button btnExit = findViewById(R.id.btnExit);

        btnGajiPegawai.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivityEries.this, GajiActivityEries.class);
            startActivity(intent);
        });

        btnPetunjuk.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivityEries.this, PetunjukActivityEries.class);
            startActivity(intent);
        });

        btnTentang.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivityEries.this, TentangActivityEries.class);
            startActivity(intent);
        });

        btnExit.setOnClickListener(v -> {
            finishAffinity();
            System.exit(0);
        });
    }
}
